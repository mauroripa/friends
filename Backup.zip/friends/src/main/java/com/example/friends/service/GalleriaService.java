package com.example.friends.service;

public interface GalleriaService {
    void removeImg(int id);
}
